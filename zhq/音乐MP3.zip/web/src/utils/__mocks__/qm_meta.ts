export const extractQQMusicMeta = jest.fn();
